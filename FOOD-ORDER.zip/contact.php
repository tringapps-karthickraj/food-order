<?php include('partials-front/menu.php'); ?>
<div >
<h2 style="text-align:center;">Contact us</h2>
<form action="contact.php" method="post">
    <table style="margin:auto;">
      <div class="elem-group">
            <tr>
              <td> <label for="name">Your Name</label></td>
              <td><input type="text" id="name" name="visitor_name" placeholder="John Doe" pattern=[A-Z\sa-z]{3,20} required></td>
            </tr>
      </div>
      <div class="elem-group">
            <tr>
              <td><label for="email">Your E-mail</label></td>
              <td><input type="email" id="email" name="visitor_email" placeholder="john.doe@email.com" required></td>
            </tr>
      </div>
      <div class="elem-group">
            <tr>
              <td><label for="department-selection">Choose Concerned Department</label></td>
              <td><select id="department-selection" name="concerned_department" required>
                  <option value="">Select a Department</option>
                  <option value="billing">Billing</option>
                  <option value="marketing">Marketing</option>
                  <option value="technical support">Technical Support</option>
                  </select></td>
            </tr>
      </div>
      <div class="elem-group">
            <tr>
              <td><label for="title">Reason For Contacting Us</label></td>
              <td><input type="text" id="title" name="email_title" required placeholder="Unable to Reset my Password" pattern=[A-Za-z0-9\s]{8,60}></td>
            </tr>
      </div>
      <div class="elem-group">
            <tr>
              <td><label for="message">Write your message</label></td>
              <td><textarea id="message" name="visitor_message" placeholder="Say whatever you want." required></textarea></td>
            </tr>
      </div>
      </table>
            <div style="text-align:center">
              <button type="submit">Send Message</button>
</div>
    
</form>
<div>
<?php
  
if($_POST) {
    $visitor_name = "";
    $visitor_email = "";
    $email_title = "";
    $concerned_department = "";
    $visitor_message = "";
    $email_body = "<div>";
      
    if(isset($_POST['visitor_name'])) {
        $visitor_name = filter_var($_POST['visitor_name'], FILTER_SANITIZE_STRING);
        $email_body .= "<div>
                           <label><b>Visitor Name:</b></label>&nbsp;<span>".$visitor_name."</span>
                        </div>";
    }
 
    if(isset($_POST['visitor_email'])) {
        $visitor_email = str_replace(array("\r", "\n", "%0a", "%0d"), '', $_POST['visitor_email']);
        $visitor_email = filter_var($visitor_email, FILTER_VALIDATE_EMAIL);
        $email_body .= "<div>
                           <label><b>Visitor Email:</b></label>&nbsp;<span>".$visitor_email."</span>
                        </div>";
    }
      
    if(isset($_POST['email_title'])) {
        $email_title = filter_var($_POST['email_title'], FILTER_SANITIZE_STRING);
        $email_body .= "<div>
                           <label><b>Reason For Contacting Us:</b></label>&nbsp;<span>".$email_title."</span>
                        </div>";
    }
      
    if(isset($_POST['concerned_department'])) {
        $concerned_department = filter_var($_POST['concerned_department'], FILTER_SANITIZE_STRING);
        $email_body .= "<div>
                           <label><b>Concerned Department:</b></label>&nbsp;<span>".$concerned_department."</span>
                        </div>";
    }
      
    if(isset($_POST['visitor_message'])) {
        $visitor_message = htmlspecialchars($_POST['visitor_message']);
        $email_body .= "<div>
                           <label><b>Visitor Message:</b></label>
                           <div>".$visitor_message."</div>
                        </div>";
    }
      
    if($concerned_department == "billing") {
        $recipient = "billing@domain.com";
    }
    else if($concerned_department == "marketing") {
        $recipient = "marketing@domain.com";
    }
    else if($concerned_department == "technical support") {
        $recipient = "tech.support@domain.com";
    }
    else {
        $recipient = "contact@domain.com";
    }
      
    $email_body .= "</div>";
 
    $headers  = 'MIME-Version: 1.0' . "\r\n"
    .'Content-type: text/html; charset=utf-8' . "\r\n"
    .'From: ' . $visitor_email . "\r\n";
      
    if(mail($recipient, $email_title, $email_body, $headers)) {
        echo "<p>Thank you for contacting us, $visitor_name. You will get a reply within 24 hours.</p>";
    } else {
        echo '<p>We are sorry but the email did not go through.</p>';
    }
      
} else {
    echo '<p>Something went wrong</p>';
}
?>
<?php include('partials-front/footer.php'); ?>