<!--Footer Section Starts-->
<div class="footer">
<div class="wrapper">
    <p class="text-centre">Serve all , Feed all..Be Happy :) </a></p>
</div>
</div>
<!--Footer Section Ends-->
</body>
</html>